# qiskit-advocate-test

This is the Qiskit Advocate testing notebook. In order to take the test, you will need to run the notebook
`qiskit_advocates_questions_090919.ipynb` in Jupyter. 

This notebook only runs correctly using Jupyter notebook. It is currently incompatible with Jupyter lab.

If you do not have Jupyter installed, we recommend the Anaconda installation
for Python 3, which includes Jupyter as well as several scientific packages.

Once you open the notebook, please follow the instructions within to take the test.

If you have any questions, please message them in the qiskit-advocates-help slack channel. Join here: 
https://join.slack.com/t/qiskit/shared_invite/enQtNjQ5OTc5ODM1ODYyLTBlMWY1ZGJiYmZkNjliZTY4MTViNTQ3NzI2ZmU2MzQxZjlhZDZlYTAzZTNlMDU0ZjVmNzEyMzY3OGE1Y2UyNjk

README090919
